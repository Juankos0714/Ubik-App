create view motel_availability
            (id, name, city, department, price_per_hour, price_per_night, rating, total_rooms, available_rooms,
             total_reservations, current_average_rating)
as
SELECT m.id,
       m.name,
       m.city,
       m.department,
       m.price_per_hour,
       m.price_per_night,
       m.rating,
       m.total_rooms,
       m.available_rooms,
       count(r.id) AS total_reservations,
       m.rating    AS current_average_rating
FROM motels m
         LEFT JOIN reservations r ON m.id = r.motel_id AND r.status::text = 'COMPLETED'::text
WHERE m.is_active = true
GROUP BY m.id, m.name, m.city, m.department, m.price_per_hour, m.price_per_night, m.rating, m.total_rooms,
         m.available_rooms;

alter table motel_availability
    owner to postgres;

