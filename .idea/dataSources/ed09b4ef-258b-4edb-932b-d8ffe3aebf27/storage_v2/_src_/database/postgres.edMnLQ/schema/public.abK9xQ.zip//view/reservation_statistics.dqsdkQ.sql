create view reservation_statistics
            (motel_id, motel_name, total_reservations, completed_reservations, cancelled_reservations, total_revenue,
             avg_reservation_value)
as
SELECT m.id                                   AS motel_id,
       m.name                                 AS motel_name,
       count(r.id)                            AS total_reservations,
       count(
               CASE
                   WHEN r.status::text = 'COMPLETED'::text THEN 1
                   ELSE NULL::integer
                   END)                       AS completed_reservations,
       count(
               CASE
                   WHEN r.status::text = 'CANCELLED'::text THEN 1
                   ELSE NULL::integer
                   END)                       AS cancelled_reservations,
       COALESCE(sum(
                        CASE
                            WHEN r.status::text = 'COMPLETED'::text THEN r.total_amount
                            ELSE 0::numeric
                            END), 0::numeric) AS total_revenue,
       COALESCE(avg(
                        CASE
                            WHEN r.status::text = 'COMPLETED'::text THEN r.total_amount
                            ELSE NULL::numeric
                            END), 0::numeric) AS avg_reservation_value
FROM motels m
         LEFT JOIN reservations r ON m.id = r.motel_id
GROUP BY m.id, m.name;

alter table reservation_statistics
    owner to postgres;

